package com.example.yourfarm.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class Coupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;

    @NotEmpty(message ="couponNumber must not be empty" )
    @Column(columnDefinition = "varchar(10) not null")
    private StringBuilder couponNumber;

    @Pattern(regexp ="^(valid|expired)$")
    @Column(columnDefinition = "varchar(100) not null")
    private String status;


    @Min(value = 20, message = "minimum value should be 20")
    @Max(value = 100, message = "maximum value should be 100")
    @Column(columnDefinition = "int not null")
    private Integer value;
}
