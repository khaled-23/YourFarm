package com.example.yourfarm.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class Farmer {
    @Id
    private Integer id;



    @NotNull(message ="Years Of Experience must not be empty" )
    @PositiveOrZero(message = "years of experience should be positive or zero")
    @Column(columnDefinition = "int not null")
    private Integer yearsOfExperience;

    @NotNull(message ="price must not be empty" )
    @Positive(message = "price should not be empty")
    @Column(columnDefinition = "int not null")
    private Integer price;

    @NotEmpty(message = "Region must not be empty")
    @Column(columnDefinition = "varchar(20) not null ")
    private String region;


    @PositiveOrZero(message = "evaluation should be positive or zero")
    @Max(value = 5, message = "evaluation maximum number should be 5")
    @Min(value = 0, message = "evaluation minimum number should be 0")
    @Column(columnDefinition = "int not null")
    private Double evaluation;

    @PositiveOrZero(message = "number of evaluation should be positive or zero")
    @Column(columnDefinition = "int not null")
    private Integer numberOfEvaluation;
    //------------------------------------------

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "farmer")
    private Set<OrderFarmer> orderFarmers;

    @OneToOne
    @MapsId
    private User user;
}
