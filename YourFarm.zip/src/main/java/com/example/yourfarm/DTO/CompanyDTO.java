package com.example.yourfarm.DTO;

import jakarta.persistence.Column;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class CompanyDTO {

    @NotEmpty(message = "username must not be empty")
    @Size(min = 5,message ="You must enter at least 5 characters" )
    private String username;

    @NotEmpty(message ="password must not be empty" )
    private String password;

    @NotEmpty(message = "name must not be empty")
    private String name ;

    @NotEmpty(message ="email must not be empty" )
    @Email(message = "provide valid email")
    private String email;

    @Pattern(regexp = "05\\d{8}")
    private String phoneNumber;

    private String imageUrl;

    @NotEmpty(message = "Region must not be empty")
    private String region;

    @NotEmpty(message = "National address must not be empty")
    @Size(min = 8, max = 8, message = "national address should be 4 characters and 4 digit")
    @Pattern(regexp = "^[A-Z]{4}[0-9]{4}$")
    private String nationalAddress;


    @NotEmpty(message ="commercialRegister must not be empty")
    @Size(min = 10, max = 10, message = "commercial register must be 10 characters")
    private String commercialRegister;





}
