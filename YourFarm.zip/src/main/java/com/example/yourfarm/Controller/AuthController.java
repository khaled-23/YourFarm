package com.example.yourfarm.Controller;

import com.example.yourfarm.API.ApiException;
import com.example.yourfarm.API.ApiResponse;
import com.example.yourfarm.Service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
//import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;
import com.example.yourfarm.Model.User;

import java.util.List;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthService authService;

    Logger logger = LoggerFactory.getLogger(AuthController.class);

//ADMIN
    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUser(){
        logger.info("all user requested");
        return ResponseEntity.ok(authService.getAllUser());
    }
//ALL
    @PostMapping("/register")
    public ResponseEntity register(@RequestBody @Valid User user){
        authService.register(user);
        logger.info("guest register");
        return ResponseEntity.ok(new ApiResponse("user added"));
    }




    @PostMapping("/login")
    public ResponseEntity login(){
        return ResponseEntity.ok().body(new ApiException("welcome"));
    }

    @PostMapping("/logout")
    public ResponseEntity logOut(){
        return ResponseEntity.ok().body(new ApiResponse("goodbye"));
    }




}
