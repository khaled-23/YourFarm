package com.example.yourfarm.Controller;

import com.example.yourfarm.Model.Farm;
import com.example.yourfarm.Model.Plant;
import com.example.yourfarm.Service.PlantService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;


import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = PlantController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
public class PlantControllerTest {

    @Autowired
    private MockMvc mockMvc;


    @MockBean
    private PlantService plantService;


    private List<Plant> plants;


    Plant plant1 = new Plant();
    Plant plant2 = new Plant();


    Plant plant = new Plant();




//    Farm farm = new Farm(null, p);






    @BeforeEach
    void setUp(){


        plant1.setId(1);
        plant1.setName("plant 1");
        plant1.setType("type 2");


        plant2.setId(2);
        plant2.setName("plant 2");
        plant2.setType("type 2");




        plants = Arrays.asList(plant1,plant2);
        plant = plant1;
    }




    @Test
    public void getAllPlant() throws Exception {
        Mockito.when(plantService.getAllPlant()).thenReturn(plants);


        mockMvc.perform(get("/api/v1/plant/plants"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].name").value("plant 1"))
                .andExpect(jsonPath("$[1].name").value("plant 2"));
    }




    @Test
    public void testFindPlantById() throws Exception {
        Integer plantId = 1;
        Mockito.when(plantService.findPlantById(plantId)).thenReturn(plant);


        mockMvc.perform(get("/api/v1/plant/find-plant-by-id/" + plantId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("plant 1"));
        verify(plantService, times(1)).findPlantById(plantId);
    }


    @Test
    public void testFindPlantByType() throws Exception {
        Integer farmId = 1;
        String type = "type1";
        List<Plant> filteredPlants = Arrays.asList(plants.get(0));


        Mockito.when(plantService.findPlantByType( type)).thenReturn(filteredPlants);


        mockMvc.perform(get("/api/v1/plant/find-plant-by-type/" + farmId + "/" + type))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].name").value("plant 1"))
                .andExpect(jsonPath("$[0].type").value("type1"));


        verify(plantService, times(1)).findPlantByType( type);
    }


    @Test
    public void testViewPlantOfFarm() throws Exception {
        String farmName = "farm 1";
        Set<Plant> plants = new HashSet<>(Arrays.asList(plant1, plant2));


        Mockito.when(plantService.ViewPlantOfFarm(farmName)).thenReturn(plants);


        mockMvc.perform(get("/api/v1/plant/view-plant-of-farm/{farm_name}", farmName))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));


        Mockito.verify(plantService, times(1)).ViewPlantOfFarm(farmName);
    }


}
