package com.example.yourfarm;




import com.example.yourfarm.Model.Farm;
import com.example.yourfarm.Model.Plant;
import com.example.yourfarm.Model.User;
import com.example.yourfarm.Repository.AuthRepository;
import com.example.yourfarm.Repository.PlantRepository;
import com.example.yourfarm.Service.PlantService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import static org.mockito.Mockito.verify;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;




@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class PlantRepositoryTest {


    @Mock
    private AuthRepository authRepository;


    @Mock
    private PlantRepository plantRepositoryMock;


    @Mock
    private PlantService plantService;




    Plant plant1, plant2, plant3;
    User user;
    Farm farm;
    @BeforeEach
    public void setUp() {
        user = new User(1, "Kholud", "87654321", "CUSTOMER", "Kholud", "kholud@gmail.com", "0551243107", "image", null, null, null, null, null);
        farm = new Farm(1, "Riyadh", "1234567890", 12345, 0.0, 0, 0, null, null, null, user);
        plant1 = new Plant(1, "plant1", "Lucky plant", 10, "Indoor plants", 1, farm);
        plant2 = new Plant(2, "plant2", "A relaxing plant", 20, "Indoor plants", 2, farm);
        plant3 = new Plant(3, "plant3", "Mint plant", 30, "Indoor plants", 3, farm);
    }


    @Test
    void testFindPlantById() {
        // تحضير البيانات المزيفة
        Plant expectedPlant = new Plant();
        expectedPlant.setId(1);
        expectedPlant.setName("Rose");


        // تعيين سلوك المكون المزيف
        when(plantRepositoryMock.findById(1)).thenReturn(Optional.of(expectedPlant));


        // استدعاء الميثود التي نريد اختبارها
        Plant result = plantRepositoryMock.findById(1).orElse(null);


        // التحقق من أن النبات المسترجع مطابق للنبات المتوقع
        assertEquals(expectedPlant, result);


        // التحقق من استدعاء المكون المزيف بشكل صحيح
        verify(plantRepositoryMock, times(1)).findById(1);
    }


    @Test
    void testFindPlantByType() {
        // تحضير البيانات المزيفة
        Plant plant1 = new Plant(1, "plant1", "Lucky plant", 10, "Indoor plants", 1, farm);
        Plant plant2 = new Plant(2, "plant2", "A relaxing plant", 20, "Indoor plants", 2, farm);
        List<Plant> expectedPlants = Arrays.asList(plant1, plant2);


        // تعيين سلوك المكون المزيف
        when(plantRepositoryMock.findPlantByType("Indoor plants")).thenReturn(expectedPlants);


        // استدعاء الميثود التي نريد اختبارها
        List<Plant> result = plantRepositoryMock.findPlantByType("Indoor plants");


        // التحقق من أن النباتات المسترجعة مطابقة للنباتات المتوقعة
        assertEquals(expectedPlants, result);


        // التحقق من استدعاء المكون المزيف بشكل صحيح
        verify(plantRepositoryMock, times(1)).findPlantByType("Indoor plants");
    }


    @Test
    void testFindPlantByNameAndFarm() {
        // تحضير البيانات المزيفة
        Plant expectedPlant = new Plant(1, "Rose", "Beautiful flower", 10, "Outdoor plants", 1, farm);


        // تعيين سلوك المكون المزيف
        when(plantRepositoryMock.findPlantByNameAndFarm("Rose", farm)).thenReturn(expectedPlant);


        // استدعاء الميثود التي نريد اختبارها
        Plant result = plantRepositoryMock.findPlantByNameAndFarm("Rose", farm);


        // التحقق من أن النبات المسترجع مطابق للنبات المتوقع
        assertEquals(expectedPlant, result);


        // التحقق من استدعاء المكون المزيف بشكل صحيح
        verify(plantRepositoryMock, times(1)).findPlantByNameAndFarm("Rose", farm);
    }


}
